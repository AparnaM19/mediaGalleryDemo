<?php $__env->startSection('content'); ?>
<ul class="nav nav-tabs">
    <li><a href="<?php echo e(url('image-gallery')); ?>">Images</a></li>
    <li><a href="<?php echo e(url('video-gallery')); ?>">Videos</a></li>
    <li class="active"><a href="<?php echo e(url('document-gallery')); ?>">Documents</a></li>
    <li><a href="<?php echo e(url('favourites')); ?>">Favourites <i class="glyphicon glyphicon-heart"></i></span></a> </li>
</ul>
<div id="documents" class="tab-pane fade in active">
  <h3>Documents</h3>
  <form action="<?php echo e(url('document-gallery')); ?>" class="form-image-upload" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>

      <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger">
              <strong>Whoops!</strong> There were some problems with your input.<br><br>
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
      <?php endif; ?>


      <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button>
              <strong><?php echo e($message); ?></strong>
      </div>
      <?php endif; ?>

      <div class="row">
          <div class="col-md-5">
              <strong>Title:</strong>
              <input type="text" name="title" class="form-control" placeholder="Title">
          </div>
          <div class="col-md-5">
              <strong>Document:</strong>
              <input type="file" name="document" class="form-control">
          </div>

          <div class="col-md-2">
              <br/>
              <button type="submit" class="btn btn-success">Upload</button>
          </div>
      </div>
  </form> 


  <div class="row">
  <div class='list-group gallery'>

      <?php if($documents->count()): ?>
          <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class='col-sm-4 col-xs-4 col-md-4 col-lg-4 mediagallery'>
                <img class="img-responsive" alt="" src="<?php echo e(asset('/')); ?>/img/pdfimg.jpeg" style="height: 140px;width: 500px;" onclick="openDocument('<?php echo e($document->document); ?>')" />
              <form action="<?php echo e(url('document-gallery',$document->id)); ?>" method="POST">
                  <input type="hidden" name="_method" value="delete">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="close-icon btn btn-danger"><i class="glyphicon glyphicon-remove"></i></button>
              </form>
                <form action="<?php echo e(url('document-gallery',$document->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="_method" value="PUT">
                    <input type="hidden" value="<?php echo e($document->favourite); ?>" name="favouriteflag">
                    <?php if($document->favourite == 1): ?>     
                        <button type="submit" class="favourite-icon btn btn-danger"><i class="glyphicon glyphicon-heart"></i></button>
                    <?php else: ?>   
                        <button type="submit" class="favourite-icon btn"><i class="glyphicon glyphicon-heart"></i></button>
                    <?php endif; ?>      
                </form>
          </div> <!-- col-6 / end -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
  </div> <!-- list-group / end -->
  </div> <!-- row / end -->
  
    <div class='modal' modal='pdfviewer' id='pdfviewer' style="height:650px">         
        <div class="modal-dialog w650">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body termsconinfo">
                    <div id="showdocument"></div>
                </div>
             </div>
        </div>            
    </div>


</div>
 <object data="url/pdftest.pdf"></object>
<style>
.pdfobject-container { height: 500px;}
.pdfobject { border: 1px solid #666; }
</style>
<script type="text/javascript">
    function openDocument(doc){
        $("#pdfviewer").modal("show");
        PDFObject.embed('/documents/'+doc, "#showdocument");
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mediaGallery/resources/views/document-gallery.blade.php ENDPATH**/ ?>