<?php $__env->startSection('content'); ?>
    <ul class="nav nav-tabs">
        <li class="active"><a href="<?php echo e(url('image-gallery')); ?>">Images</a></li>
        <li><a href="<?php echo e(url('video-gallery')); ?>">Videos</a></li>
        <li><a href="<?php echo e(url('document-gallery')); ?>">Documents</a></li>
            <li><a href="<?php echo e(url('favourites')); ?>">Favourites <i class="glyphicon glyphicon-heart"></i></a> </li>
    </ul>
      <div id="images" class="tab-pane fade in active">
        <h3>Images</h3>
        <form action="<?php echo e(url('image-gallery')); ?>" class="form-image-upload" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-5">
                <strong>Title:</strong>
                <input type="text" name="title" class="form-control" placeholder="Title">
            </div>
            <div class="col-md-5">
                <strong>Image:</strong>
                <input type="file" name="image" class="form-control">
            </div>

            <div class="col-md-2">
                <br/>
                <button type="submit" class="btn btn-success">Upload</button>
            </div>
        </div>
    </form> 


    <div class="row">
        <div class='list-group gallery'>

            <?php if($images->count()): ?>
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                    <a class="thumbnail fancybox" rel="ligthbox" href="<?php echo e(asset('/')); ?>/images/<?php echo e($image->image); ?>">

                        <img class="img-responsive" alt="" src="<?php echo e(asset('/')); ?>/images/<?php echo e($image->image); ?>" />
                        <div class='text-center'>
                            <small class='text-muted'><?php echo e($image->title); ?></small>
                        </div> <!-- text-center / end -->
                    </a>

                    <form action="<?php echo e(url('image-gallery',$image->id)); ?>" method="POST">
                        <input type="hidden" name="_method" value="delete">
                        <?php echo csrf_field(); ?>

                        <button type="submit" class="close-icon btn btn-danger"><i class="glyphicon glyphicon-remove"></i></button>                        
                    </form>
                    <form action="<?php echo e(url('image-gallery',$image->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="_method" value="PUT">
                        <input type="hidden" value="<?php echo e($image->favourite); ?>" name="favouriteflag">
                        <?php if($image->favourite == 1): ?>     
                            <button type="submit" class="favourite-icon btn btn-danger"><i class="glyphicon glyphicon-heart"></i></button>
                        <?php else: ?>   
                            <button type="submit" class="favourite-icon btn"><i class="glyphicon glyphicon-heart"></i></button>
                        <?php endif; ?>      
                    </form>
                </div> <!-- col-6 / end -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div> <!-- list-group / end -->
        </div> <!-- row / end -->
    
      </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mediaGallery/resources/views/image-gallery.blade.php ENDPATH**/ ?>