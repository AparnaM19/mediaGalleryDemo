<!DOCTYPE html>

<html>

<head>

    <title>Media Gallery</title>
    
    

    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/jquery.fancybox.min.css" media="screen">

  
    

<!--    <script src="stylesheet" href="<?php echo e(asset('/')); ?>js/jquery.min.js"></script>
    <script src="stylesheet" href="<?php echo e(asset('/')); ?>js/jquery.fancybox.min.js"></script> -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
    <script type="text/javascript" href="<?php echo e(asset('/')); ?>js/pdfobject/pdfobject.js"></script>


    <style type="text/css">

    .gallery
    {
        display: inline-block;
        margin-top: 20px;
    }

    .close-icon{
    	border-radius: 50%;
        position: absolute;
        right: 5px;
        top: -10px;
        padding: 5px 8px;
    }
    
    .favourite-icon{
    	border-radius: 50%;
        position: absolute;
        right: 17px;
        bottom: 21px;
        padding: 5px 8px;
    }
    .favourite-ic{
    	border-radius: 50%;
        padding: 1px 4px;
        position: relative;
        right: -12px;
    }

    .form-image-upload{
        background: #e8e8e8 none repeat scroll 0 0;
        padding: 15px;
    }
    .mediagallery{
        line-height: 1.42857143;
        background-color: #fff;
        border: 1px solid #ddd;
    }

    </style>

</head>

<body>


<div class="container">
    <h2>Media Gallery</h2>
    
    <div class="tab-content">
           <?php echo $__env->yieldContent('content'); ?>   
    </div>
</div> <!-- container / end -->


</body>


<script type="text/javascript">

    $(document).ready(function(){

        $(".fancybox").fancybox({
            openEffect: "none",
            closeEffect: "none"
        });

    });

</script>

</html><?php /**PATH /var/www/html/mediaGallery/resources/views/layouts/master.blade.php ENDPATH**/ ?>