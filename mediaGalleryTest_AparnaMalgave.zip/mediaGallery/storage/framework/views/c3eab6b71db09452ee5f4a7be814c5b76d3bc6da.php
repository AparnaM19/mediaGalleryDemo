<?php $__env->startSection('content'); ?>
    <ul class="nav nav-tabs">
        <li><a href="<?php echo e(url('image-gallery')); ?>">Images</a></li>
        <li><a href="<?php echo e(url('video-gallery')); ?>">Videos</a></li>
        <li><a href="<?php echo e(url('document-gallery')); ?>">Documents</a></li>
        <li class="active"><a href="<?php echo e(url('favourites')); ?>">Favourites <span class="favourite-ic btn btn-danger"><i class="glyphicon glyphicon-heart"></i></span></a> </li>
    </ul>
    <div id="favourites" class="tab-pane fade in active">
        <h3>Images</h3>
        


        <div class="row">
            <div class='list-group gallery'>

                <?php if($images->count()): ?>
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                        <a class="thumbnail fancybox" rel="ligthbox" href="<?php echo e(asset('/')); ?>/images/<?php echo e($image->image); ?>">

                            <img class="img-responsive" alt="" src="<?php echo e(asset('/')); ?>/images/<?php echo e($image->image); ?>" />
                            <div class='text-center'>
                                <small class='text-muted'><?php echo e($image->title); ?></small>
                            </div> <!-- text-center / end -->
                        </a>
                    </div> <!-- col-6 / end -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div> <!-- list-group / end -->
        </div> <!-- row / end -->
    
        <hr style="border: 1px solid #ddd">
        
        <h3>Videos</h3
        <div class="row">
            <div class='list-group gallery'>

                <?php if($videos->count()): ?>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class='col-sm-6 col-xs-6 col-md-6 col-lg-6 mediagallery'>
                        <video width="400" style="height: 225px" controls>
                          <source src="<?php echo e(asset('/')); ?>/videos/<?php echo e($video->video); ?>" type="video/mp4">
                          <source src="<?php echo e(asset('/')); ?>/videos/<?php echo e($video->video); ?>" type="video/ogg">
                          Your browser does not support HTML5 video.
                        </video>
                          <div class='text-center'>
                             <small class='text-muted'><?php echo e($video->title); ?></small>
                          </div> <!-- text-center / end -->

                    </div> <!-- col-6 / end -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div> <!-- list-group / end -->
        </div> <!-- row / end -->
    
        <hr style="border: 1px solid #ddd">
        <h3>Documents</h3>
        


        <div class="row">
            <div class='list-group gallery'>

                 <?php if($documents->count()): ?>
                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class='col-sm-4 col-xs-4 col-md-4 col-lg-4 mediagallery'>
                         <img class="img-responsive" alt="" src="<?php echo e(asset('/')); ?>/img/pdfimg.jpeg" style="height: 140px;width: 500px;" onclick="openDocument('<?php echo e($document->document); ?>')" />                        
                    </div> <!-- col-6 / end -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div> <!-- list-group / end -->
        </div> <!-- row / end -->
    
      </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/mediaGallery/resources/views/favourites-gallery.blade.php ENDPATH**/ ?>