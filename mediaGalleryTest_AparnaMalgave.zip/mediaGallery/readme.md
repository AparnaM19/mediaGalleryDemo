test mediaGallery

Steps to Run Project

1.Import SQL file path- database_changes/mediagallery.sql in MySql
	or 
run 'php artisan migrate' in 'mediaGallery' project folder

2.Update database connection setting from .env DB_CONNECTION=mysql 
         DB_HOST=172.16.0.182 DB_PORT=3306 
         DB_DATABASE=mediagallery
         DB_USERNAME=root 
         DB_PASSWORD=m/RlxUJMhQW3
3.Run Project using- http://localhost/mediaGallery/public/
