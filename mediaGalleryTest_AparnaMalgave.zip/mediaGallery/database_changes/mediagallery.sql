/*
SQLyog Community v12.09 (64 bit)
MySQL - 5.5.38-0ubuntu0.12.04.1-log : Database - mediagallery
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`mediagallery` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mediagallery`;

/*Table structure for table `document_gallery` */

DROP TABLE IF EXISTS `document_gallery`;

CREATE TABLE `document_gallery` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `document` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `favourite` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `document_gallery` */

insert  into `document_gallery`(`id`,`title`,`document`,`favourite`,`created_at`,`updated_at`) values (2,'testV','1566376335.pdf',1,'2019-08-21 08:32:15','2019-08-21 13:22:10');

/*Table structure for table `image_gallery` */

DROP TABLE IF EXISTS `image_gallery`;

CREATE TABLE `image_gallery` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `favourite` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `image_gallery` */

insert  into `image_gallery`(`id`,`title`,`image`,`favourite`,`created_at`,`updated_at`) values (4,'testV','1566382210.jpeg','1','2019-08-21 10:10:10','2019-08-21 10:40:32'),(5,'test','1566382483.jpeg','1','2019-08-21 10:14:43','2019-08-21 14:22:19');

/*Table structure for table `video_gallery` */

DROP TABLE IF EXISTS `video_gallery`;

CREATE TABLE `video_gallery` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `video` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `favourite` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*Data for the table `video_gallery` */

insert  into `video_gallery`(`id`,`title`,`video`,`favourite`,`created_at`,`updated_at`) values (3,'Video1','1566376399.SampleVideo_1280x720_1mb.mp4',1,'2019-08-21 08:33:19','2019-08-21 10:43:52'),(4,'testV','1566376482.IMG_0772.MP4',0,'2019-08-21 08:34:42','2019-08-21 10:43:54');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
