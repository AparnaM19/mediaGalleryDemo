<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('image-gallery', 'ImageGalleryController@index');
Route::post('image-gallery', 'ImageGalleryController@upload');
Route::put('image-gallery/{id}', 'ImageGalleryController@favourite');
Route::delete('image-gallery/{id}', 'ImageGalleryController@destroy');

Route::get('video-gallery', 'VideoGalleryController@index');
Route::post('video-gallery', 'VideoGalleryController@upload');
Route::put('video-gallery/{id}', 'VideoGalleryController@favourite');
Route::delete('video-gallery/{id}', 'VideoGalleryController@destroy');

Route::get('document-gallery', 'DocumentGalleryController@index');
Route::post('document-gallery', 'DocumentGalleryController@upload');
Route::put('document-gallery/{id}', 'DocumentGalleryController@favourite');
Route::delete('document-gallery/{id}', 'DocumentGalleryController@destroy');

Route::get('favourites', 'ImageGalleryController@favourites');
