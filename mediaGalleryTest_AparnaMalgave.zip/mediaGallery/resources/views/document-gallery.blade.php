@extends('layouts.master')
@section('content')
<ul class="nav nav-tabs">
    <li><a href="{{ url('image-gallery') }}">Images</a></li>
    <li><a href="{{ url('video-gallery') }}">Videos</a></li>
    <li class="active"><a href="{{ url('document-gallery') }}">Documents</a></li>
    <li><a href="{{ url('favourites') }}">Favourites <i class="glyphicon glyphicon-heart"></i></span></a> </li>
</ul>
<div id="documents" class="tab-pane fade in active">
  <h3>Documents</h3>
  <form action="{{ url('document-gallery') }}" class="form-image-upload" method="POST" enctype="multipart/form-data">
      {!! csrf_field() !!}
      @if (count($errors) > 0)
          <div class="alert alert-danger">
              <strong>Whoops!</strong> There were some problems with your input.<br><br>
              <ul>
                  @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                  @endforeach
              </ul>
          </div>
      @endif


      @if ($message = Session::get('success'))
      <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button>
              <strong>{{ $message }}</strong>
      </div>
      @endif

      <div class="row">
          <div class="col-md-5">
              <strong>Title:</strong>
              <input type="text" name="title" class="form-control" placeholder="Title">
          </div>
          <div class="col-md-5">
              <strong>Document:</strong>
              <input type="file" name="document" class="form-control">
          </div>

          <div class="col-md-2">
              <br/>
              <button type="submit" class="btn btn-success">Upload</button>
          </div>
      </div>
  </form> 


  <div class="row">
  <div class='list-group gallery'>

      @if($documents->count())
          @foreach($documents as $document)
          <div class='col-sm-4 col-xs-4 col-md-4 col-lg-4 mediagallery'>
                <img class="img-responsive" alt="" src="{{asset('/')}}/img/pdfimg.jpeg" style="height: 140px;width: 500px;" onclick="openDocument('{{$document->document }}')" />
              <form action="{{ url('document-gallery',$document->id) }}" method="POST">
                  <input type="hidden" name="_method" value="delete">
                  {!! csrf_field() !!}
                  <button type="submit" class="close-icon btn btn-danger"><i class="glyphicon glyphicon-remove"></i></button>
              </form>
                <form action="{{ url('document-gallery',$document->id) }}" method="POST">
                    {!! csrf_field() !!}
                    <input type="hidden" name="_method" value="PUT">
                    <input type="hidden" value="{{$document->favourite}}" name="favouriteflag">
                    @if($document->favourite == 1)     
                        <button type="submit" class="favourite-icon btn btn-danger"><i class="glyphicon glyphicon-heart"></i></button>
                    @else   
                        <button type="submit" class="favourite-icon btn"><i class="glyphicon glyphicon-heart"></i></button>
                    @endif      
                </form>
          </div> <!-- col-6 / end -->
          @endforeach
      @endif
  </div> <!-- list-group / end -->
  </div> <!-- row / end -->
  
    <div class='modal' modal='pdfviewer' id='pdfviewer' style="height:650px">         
        <div class="modal-dialog w650">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body termsconinfo">
                    <div id="showdocument"></div>
                </div>
             </div>
        </div>            
    </div>


</div>
 <object data="url/pdftest.pdf"></object>
<style>
.pdfobject-container { height: 500px;}
.pdfobject { border: 1px solid #666; }
</style>
<script type="text/javascript">
    function openDocument(doc){
        $("#pdfviewer").modal("show");
        PDFObject.embed('/documents/'+doc, "#showdocument");
    }
</script>
@stop