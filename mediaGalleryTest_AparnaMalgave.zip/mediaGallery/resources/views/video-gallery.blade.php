@extends('layouts.master')
@section('content')
<ul class="nav nav-tabs">
    <li><a href="{{ url('image-gallery') }}">Images</a></li>
    <li class="active"><a href="{{ url('video-gallery') }}">Videos</a></li>
    <li><a href="{{ url('document-gallery') }}">Documents</a></li>
    <li><a href="{{ url('favourites') }}">Favourites <i class="glyphicon glyphicon-heart"></i></a> </li>
</ul>
<div id="videos" class="tab-pane fade in active">
  <h3>Videos</h3>
  <form action="{{ url('video-gallery') }}" class="form-image-upload" method="POST" enctype="multipart/form-data">
      {!! csrf_field() !!}
      @if (count($errors) > 0)
          <div class="alert alert-danger">
              <strong>Whoops!</strong> There were some problems with your input.<br><br>
              <ul>
                  @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                  @endforeach
              </ul>
          </div>
      @endif


      @if ($message = Session::get('success'))
      <div class="alert alert-success alert-block">
          <button type="button" class="close" data-dismiss="alert">×</button>
              <strong>{{ $message }}</strong>
      </div>
      @endif

      <div class="row">
          <div class="col-md-5">
              <strong>Title:</strong>
              <input type="text" name="title" class="form-control" placeholder="Title">
          </div>
          <div class="col-md-5">
              <strong>Video:</strong>
              <input type="file" name="video" class="form-control">
          </div>

          <div class="col-md-2">
              <br/>
              <button type="submit" class="btn btn-success">Upload</button>
          </div>
      </div>
  </form> 


  <div class="row">
  <div class='list-group gallery'>

      @if($videos->count())
          @foreach($videos as $video)
          <div class='col-sm-6 col-xs-6 col-md-6 col-lg-6 mediagallery'>
              <video width="400" style="height: 225px" controls>
                <source src="{{asset('/')}}/videos/{{ $video->video }}" type="video/mp4">
                <source src="{{asset('/')}}/videos/{{ $video->video }}" type="video/ogg">
                Your browser does not support HTML5 video.
              </video>
                <div class='text-center'>
                   <small class='text-muted'>{{ $video->title }}</small>
                </div> <!-- text-center / end -->
              

                <form action="{{ url('video-gallery',$video->id) }}" method="POST">
                    <input type="hidden" name="_method" value="delete">
                    {!! csrf_field() !!}
                    <button type="submit" class="close-icon btn btn-danger"><i class="glyphicon glyphicon-remove"></i></button>
                </form>
                <form action="{{ url('video-gallery',$video->id) }}" method="POST">
                    {!! csrf_field() !!}
                    <input type="hidden" name="_method" value="PUT">
                    <input type="hidden" value="{{$video->favourite}}" name="favouriteflag">
                    @if($video->favourite == 1)     
                        <button type="submit" class="favourite-icon btn btn-danger"><i class="glyphicon glyphicon-heart"></i></button>
                    @else   
                        <button type="submit" class="favourite-icon btn"><i class="glyphicon glyphicon-heart"></i></button>
                    @endif      
                </form>
          </div> <!-- col-6 / end -->
          @endforeach
      @endif
  </div> <!-- list-group / end -->
  </div> <!-- row / end -->

</div>
@stop