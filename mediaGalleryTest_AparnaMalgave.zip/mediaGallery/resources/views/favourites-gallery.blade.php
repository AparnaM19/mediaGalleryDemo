@extends('layouts.master')
@section('content')
    <ul class="nav nav-tabs">
        <li><a href="{{ url('image-gallery') }}">Images</a></li>
        <li><a href="{{ url('video-gallery') }}">Videos</a></li>
        <li><a href="{{ url('document-gallery') }}">Documents</a></li>
        <li class="active"><a href="{{ url('favourites') }}">Favourites <span class="favourite-ic btn btn-danger"><i class="glyphicon glyphicon-heart"></i></span></a> </li>
    </ul>
    <div id="favourites" class="tab-pane fade in active">
        <h3>Images</h3>
        


        <div class="row">
            <div class='list-group gallery'>

                @if($images->count())
                    @foreach($images as $image)
                    <div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
                        <a class="thumbnail fancybox" rel="ligthbox" href="{{asset('/')}}/images/{{ $image->image }}">

                            <img class="img-responsive" alt="" src="{{asset('/')}}/images/{{ $image->image }}" />
                            <div class='text-center'>
                                <small class='text-muted'>{{ $image->title }}</small>
                            </div> <!-- text-center / end -->
                        </a>
                    </div> <!-- col-6 / end -->
                    @endforeach
                @endif
            </div> <!-- list-group / end -->
        </div> <!-- row / end -->
    
        <hr style="border: 1px solid #ddd">
        
        <h3>Videos</h3
        <div class="row">
            <div class='list-group gallery'>

                @if($videos->count())
                    @foreach($videos as $video)
                    <div class='col-sm-6 col-xs-6 col-md-6 col-lg-6 mediagallery'>
                        <video width="400" style="height: 225px" controls>
                          <source src="{{asset('/')}}/videos/{{ $video->video }}" type="video/mp4">
                          <source src="{{asset('/')}}/videos/{{ $video->video }}" type="video/ogg">
                          Your browser does not support HTML5 video.
                        </video>
                          <div class='text-center'>
                             <small class='text-muted'>{{ $video->title }}</small>
                          </div> <!-- text-center / end -->

                    </div> <!-- col-6 / end -->
                    @endforeach
                @endif
            </div> <!-- list-group / end -->
        </div> <!-- row / end -->
    
        <hr style="border: 1px solid #ddd">
        <h3>Documents</h3>
        


        <div class="row">
            <div class='list-group gallery'>

                 @if($documents->count())
                    @foreach($documents as $document)
                    <div class='col-sm-4 col-xs-4 col-md-4 col-lg-4 mediagallery'>
                         <img class="img-responsive" alt="" src="{{asset('/')}}/img/pdfimg.jpeg" style="height: 140px;width: 500px;" onclick="openDocument('{{$document->document }}')" />                        
                    </div> <!-- col-6 / end -->
                    @endforeach
                @endif
            </div> <!-- list-group / end -->
        </div> <!-- row / end -->
    
      </div>    
@stop
