<?php

namespace App\Http\Controllers;
use App\VideoGallery;
use Illuminate\Http\Request;

class VideoGalleryController extends Controller
{
    public function index()
    {
    	$videos = VideoGallery::get();
    	return view('video-gallery',compact('videos'));
    }
    public function upload(Request $request)
    {

    	$this->validate($request, [
            'title' => 'required',
            'video' => 'required|mimes:mp4,ogx,oga,ogv,ogg,webm|max:2048',
        ]);


        $input['video'] = time().'.'.$request->video->getClientOriginalName();

        $request->video->move(public_path('videos'), $input['video']);


        $input['title'] = $request->title;

        VideoGallery::create($input);


    	return back()->with('success','Video Uploaded successfully.');

    }
    
    public function favourite(Request $request,$id)
    {
        if($request->favouriteflag == 0){
            $flag = 1;
        } else {
            $flag = 0;
        }
        $videoGallery = VideoGallery::find($id);
        $videoGallery->favourite = $flag;
        $videoGallery->save();
    	return back();
    }
    
    public function destroy($id)
    {
    	VideoGallery::find($id)->delete();
    	return back()->with('success','Video removed successfully.');	

    }
}
