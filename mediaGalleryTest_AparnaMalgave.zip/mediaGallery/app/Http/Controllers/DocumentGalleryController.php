<?php

namespace App\Http\Controllers;
use App\DocumentGallery;
use Illuminate\Http\Request;

class DocumentGalleryController extends Controller
{
    public function index()
    {
    	$documents = DocumentGallery::get();
    	return view('document-gallery',compact('documents'));
    }
    public function upload(Request $request)
    {

    	$this->validate($request, [
            'title' => 'required',
            'document' => 'required|mimes:pdf|max:10000',
        ]);


        $input['document'] = time().'.'.$request->document->getClientOriginalExtension();

        $request->document->move(public_path('documents'), $input['document']);


        $input['title'] = $request->title;

        DocumentGallery::create($input);


    	return back()->with('success','Document Uploaded successfully.');

    }
    
    public function favourite(Request $request,$id)
    {
        if($request->favouriteflag == 0){
            $flag = 1;
        } else {
            $flag = 0;
        }
        $documentGallery = DocumentGallery::find($id);
        $documentGallery->favourite = $flag;
        $documentGallery->save();
    	return back();
    }
    
    public function destroy($id)
    {
    	DocumentGallery::find($id)->delete();
    	return back()->with('success','Document removed successfully.');	

    }
}
