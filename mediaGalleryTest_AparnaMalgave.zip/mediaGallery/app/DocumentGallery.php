<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DocumentGallery extends Model
{
    protected $table = 'document_gallery';

    protected $fillable = ['title','document'];
}
